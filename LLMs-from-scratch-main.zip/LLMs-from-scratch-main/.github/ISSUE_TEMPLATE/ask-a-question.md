---
name: Ask a Question
about: Ask questions related to the book
title: ''
labels: [question]
assignees: rasbt

---

If you have a question that is not a bug, please consider asking it in this GitHub repository's [discussion forum](https://github.com/rasbt/LLMs-from-scratch/discussions).
