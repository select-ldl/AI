# More Efficient Multi-Head Attention Implementations

- [mha-implementations.ipynb](mha-implementations.ipynb) contains and compares different implementations of multi-head attention