# Chapter 3: Coding Attention Mechanisms

## Main Chapter Code

- [01_main-chapter-code](01_main-chapter-code) contains the main chapter code.

## Bonus Materials

- [02_bonus_efficient-multihead-attention](02_bonus_efficient-multihead-attention) implements and compares different implementation variants of multihead-attention