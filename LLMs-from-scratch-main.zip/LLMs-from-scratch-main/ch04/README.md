# Chapter 4: Implementing a GPT Model from Scratch to Generate Text

## Main Chapter Code

- [01_main-chapter-code](01_main-chapter-code) contains the main chapter code.

## Optional Code

- [02_performance-analysis](02_performance-analysis) contains optional code analyzing the performance of the GPT model(s) implemented in the main chapter.

